(function() {
	'use strict';

	var settings = window.configuratoreVernici || {
		ajaxUrl: '',
		nonce: '',
		safetyMargin: 1.10,
		freeDeliveryThreshold: 30,
		texts: {
			selectProduct: 'Seleziona un prodotto valido.',
			enterMq: 'Inserisci i metri quadri da verniciare.',
			enterEmail: 'Inserisci un indirizzo email valido.',
			genericError: 'Si e verificato un errore. Riprova piu tardi.',
			freeDelivery: 'Questo quantitativo ti garantisce la consegna gratuita in loco!',
			addLiters: 'Aggiungi altri {litri} Litri alla tua richiesta (es. scorte di magazzino) per ottenere la consegna gratuita in cantiere/officina!'
		}
	};

	function parseNumber(value) {
		if (typeof value !== 'string') {
			return Number(value) || 0;
		}

		return Number(value.replace(',', '.')) || 0;
	}

	function formatLiters(value) {
		return new Intl.NumberFormat('it-IT', {
			minimumFractionDigits: 2,
			maximumFractionDigits: 2
		}).format(value);
	}

	function setMessage(container, message, type) {
		if (!container) {
			return;
		}

		container.textContent = message || '';
		container.classList.remove('is-error', 'is-success');

		if (type) {
			container.classList.add('is-' + type);
		}
	}

	function getSelectedProduct(productField) {
		if (!productField || !productField.selectedOptions.length) {
			return null;
		}

		var option = productField.selectedOptions[0];
		var yieldValue = parseNumber(option.dataset.resa || '0');

		if (!option.value || yieldValue <= 0) {
			return null;
		}

		return {
			id: option.value,
			name: option.dataset.productName || option.textContent.trim(),
			yieldValue: yieldValue
		};
	}

	function initConfigurator(root) {
		var calculationForm = root.querySelector('[data-configuratore-calcolo]');
		var quoteForm = root.querySelector('[data-configuratore-preventivo]');
		var productField = root.querySelector('[data-configuratore-prodotto]');
		var materialField = root.querySelector('[data-configuratore-materiale]');
		var toolField = root.querySelector('[data-configuratore-strumento]');
		var mqField = root.querySelector('[data-configuratore-mq]');
		var emailField = root.querySelector('[data-configuratore-email]');
		var resultBox = root.querySelector('[data-configuratore-risultato]');
		var litersOutput = root.querySelector('[data-configuratore-litri]');
		var deliveryMessage = root.querySelector('[data-configuratore-consegna]');
		var messageBox = root.querySelector('[data-configuratore-messaggio]');
		var calculatedLiters = 0;

		if (!calculationForm || !quoteForm || !productField || !mqField) {
			return;
		}

		function calculate() {
			var selectedProduct = getSelectedProduct(productField);
			var mq = parseNumber(mqField.value);
			var margin = parseNumber(String(settings.safetyMargin || '1.10'));
			var freeDeliveryThreshold = parseNumber(String(settings.freeDeliveryThreshold || '30'));

			if (!selectedProduct) {
				setMessage(messageBox, settings.texts.selectProduct, 'error');
				return false;
			}

			if (mq <= 0) {
				setMessage(messageBox, settings.texts.enterMq, 'error');
				return false;
			}

			calculatedLiters = Math.round(((mq / selectedProduct.yieldValue) * margin) * 100) / 100;
			litersOutput.textContent = formatLiters(calculatedLiters);
			updateDeliveryMessage(deliveryMessage, calculatedLiters, freeDeliveryThreshold);
			resultBox.hidden = false;
			quoteForm.hidden = false;
			setMessage(messageBox, '', null);

			return true;
		}

		function updateDeliveryMessage(container, liters, threshold) {
			if (!container) {
				return;
			}

			container.classList.remove('is-success', 'is-warning');

			if (threshold <= 0) {
				container.textContent = '';
				return;
			}

			if (liters >= threshold) {
				container.textContent = settings.texts.freeDelivery;
				container.classList.add('is-success');
				return;
			}

			var missingLiters = Math.max(0, Math.round((threshold - liters) * 100) / 100);
			container.textContent = settings.texts.addLiters.replace('{litri}', formatLiters(missingLiters));
			container.classList.add('is-warning');
		}

		calculationForm.addEventListener('submit', function(event) {
			event.preventDefault();
			calculate();
		});

		productField.addEventListener('change', function() {
			if (mqField.value) {
				calculate();
			}
		});

		mqField.addEventListener('input', function() {
			if (productField.value && mqField.value) {
				calculate();
			}
		});

		quoteForm.addEventListener('submit', function(event) {
			event.preventDefault();

			var selectedProduct = getSelectedProduct(productField);
			var mq = parseNumber(mqField.value);
			var email = emailField ? emailField.value.trim() : '';

			if (!calculate() || !selectedProduct || mq <= 0 || calculatedLiters <= 0) {
				return;
			}

			if (!email || !emailField.checkValidity()) {
				setMessage(messageBox, settings.texts.enterEmail, 'error');
				return;
			}

			var submitButton = quoteForm.querySelector('button[type="submit"]');
			var originalText = submitButton ? submitButton.textContent : '';
			var formData = new FormData();

			formData.append('action', 'configuratore_vernici_request_quote');
			formData.append('nonce', settings.nonce);
			formData.append('email', email);
			formData.append('product_id', selectedProduct.id);
			formData.append('product', selectedProduct.name);
			formData.append('material', materialField ? materialField.value : '');
			formData.append('tool', toolField ? toolField.value : '');
			formData.append('mq', String(mq));
			formData.append('litri', String(calculatedLiters));

			if (submitButton) {
				submitButton.disabled = true;
				submitButton.textContent = 'Invio in corso...';
			}

			setMessage(messageBox, '', null);

			fetch(settings.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				body: formData
			})
				.then(function(response) {
					return response.json();
				})
				.then(function(payload) {
					if (!payload || !payload.success) {
						throw new Error(payload && payload.data && payload.data.message ? payload.data.message : settings.texts.genericError);
					}

					setMessage(messageBox, payload.data.message, 'success');
					quoteForm.reset();
					quoteForm.hidden = true;
				})
				.catch(function(error) {
					setMessage(messageBox, error.message || settings.texts.genericError, 'error');
				})
				.finally(function() {
					if (submitButton) {
						submitButton.disabled = false;
						submitButton.textContent = originalText;
					}
				});
		});
	}

	document.addEventListener('DOMContentLoaded', function() {
		document.querySelectorAll('[data-configuratore-vernici]').forEach(initConfigurator);
	});
})();
