<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://acquistasitoweb.com
 * @since      1.0.0
 *
 * @package    Configuratore_Vernici
 * @subpackage Configuratore_Vernici/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Configuratore_Vernici
 * @subpackage Configuratore_Vernici/public
 * @author     Acquistasitoweb <info@acquistasitoweb.com>
 */
class Configuratore_Vernici_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Configuratore_Vernici_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Configuratore_Vernici_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/configuratore-vernici-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Configuratore_Vernici_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Configuratore_Vernici_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/configuratore-vernici-public.js', array(), $this->version, true );

		wp_localize_script(
			$this->plugin_name,
			'configuratoreVernici',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'nonce'        => wp_create_nonce( 'configuratore_vernici_preventivo' ),
				'safetyMargin' => $this->get_safety_margin_multiplier(),
				'freeDeliveryThreshold' => $this->get_free_delivery_threshold(),
				'texts'        => array(
					'selectProduct' => __( 'Seleziona un prodotto valido.', 'configuratore-vernici' ),
					'enterMq'       => __( 'Inserisci i metri quadri da verniciare.', 'configuratore-vernici' ),
					'enterEmail'    => __( 'Inserisci un indirizzo email valido.', 'configuratore-vernici' ),
					'genericError'  => __( 'Si è verificato un errore. Riprova più tardi.', 'configuratore-vernici' ),
					'freeDelivery'  => __( 'Questo quantitativo ti garantisce la consegna gratuita in loco!', 'configuratore-vernici' ),
					'addLiters'     => __( 'Aggiungi altri {litri} Litri alla tua richiesta (es. scorte di magazzino) per ottenere la consegna gratuita in cantiere/officina!', 'configuratore-vernici' ),
				),
			)
		);

	}

	/**
	 * Register the public shortcode.
	 *
	 * @since    1.0.0
	 */
	public function register_shortcode() {
		add_shortcode( 'configuratore_vernici', array( $this, 'render_configurator_shortcode' ) );
	}

	/**
	 * Render the paint configurator form.
	 *
	 * @since    1.0.0
	 * @return   string
	 */
	public function render_configurator_shortcode() {
		$products = $this->get_products_with_yield();
		$materials = $this->get_configurator_posts( 'cv_materiale' );
		$tools = $this->get_configurator_posts( 'cv_strumento' );
		$urgent_phone = get_option( 'configuratore_vernici_urgent_phone', '' );
		$urgent_phone_href = $this->get_phone_href( $urgent_phone );

		ob_start();
		?>
		<div class="configuratore-vernici" data-configuratore-vernici>
			<form class="configuratore-vernici__form" data-configuratore-calcolo>
				<div class="configuratore-vernici__field">
					<label for="configuratore-vernici-prodotto"><?php esc_html_e( 'Prodotto o lavorazione', 'configuratore-vernici' ); ?></label>
					<select id="configuratore-vernici-prodotto" name="prodotto" required data-configuratore-prodotto>
						<option value=""><?php esc_html_e( 'Seleziona un prodotto', 'configuratore-vernici' ); ?></option>
						<?php foreach ( $products as $product ) : ?>
							<option
								value="<?php echo esc_attr( $product['id'] ); ?>"
								data-resa="<?php echo esc_attr( $product['resa_litro'] ); ?>"
								data-product-name="<?php echo esc_attr( $product['title'] ); ?>"
							>
								<?php echo esc_html( $product['title'] ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>

				<?php if ( ! empty( $materials ) ) : ?>
					<div class="configuratore-vernici__field">
						<label for="configuratore-vernici-materiale"><?php esc_html_e( 'Materiale o supporto', 'configuratore-vernici' ); ?></label>
						<select id="configuratore-vernici-materiale" name="materiale" data-configuratore-materiale>
							<option value=""><?php esc_html_e( 'Seleziona un materiale', 'configuratore-vernici' ); ?></option>
							<?php foreach ( $materials as $material ) : ?>
								<option value="<?php echo esc_attr( $material['title'] ); ?>"><?php echo esc_html( $material['title'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $tools ) ) : ?>
					<div class="configuratore-vernici__field">
						<label for="configuratore-vernici-strumento"><?php esc_html_e( 'Strumento di applicazione', 'configuratore-vernici' ); ?></label>
						<select id="configuratore-vernici-strumento" name="strumento" data-configuratore-strumento>
							<option value=""><?php esc_html_e( 'Seleziona uno strumento', 'configuratore-vernici' ); ?></option>
							<?php foreach ( $tools as $tool ) : ?>
								<option value="<?php echo esc_attr( $tool['title'] ); ?>"><?php echo esc_html( $tool['title'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				<?php endif; ?>

				<div class="configuratore-vernici__field">
					<label for="configuratore-vernici-mq"><?php esc_html_e( 'Metri quadri da verniciare', 'configuratore-vernici' ); ?></label>
					<input id="configuratore-vernici-mq" type="number" name="mq" min="0.01" step="0.01" placeholder="<?php esc_attr_e( 'Es. 120', 'configuratore-vernici' ); ?>" required data-configuratore-mq>
				</div>

				<button type="submit" class="button primary"><?php esc_html_e( 'Calcola litri necessari', 'configuratore-vernici' ); ?></button>
			</form>

			<div class="configuratore-vernici__result" hidden data-configuratore-risultato>
				<p>
					<?php esc_html_e( 'Litri stimati:', 'configuratore-vernici' ); ?>
					<strong><span data-configuratore-litri>0</span> <?php esc_html_e( 'L', 'configuratore-vernici' ); ?></strong>
				</p>
				<p class="configuratore-vernici__note"><?php esc_html_e( 'Il calcolo include il margine di sicurezza impostato per il configuratore.', 'configuratore-vernici' ); ?></p>
				<p class="configuratore-vernici__delivery-message" data-configuratore-consegna></p>
				<?php if ( '' !== $urgent_phone_href ) : ?>
					<p class="configuratore-vernici__urgent">
						<a class="button secondary" href="<?php echo esc_url( $urgent_phone_href ); ?>">
							<?php esc_html_e( 'Chiama per ordini urgenti', 'configuratore-vernici' ); ?>
						</a>
					</p>
				<?php endif; ?>
			</div>

			<form class="configuratore-vernici__email-form" hidden data-configuratore-preventivo>
				<div class="configuratore-vernici__field">
					<label for="configuratore-vernici-email"><?php esc_html_e( 'Email per ricevere il preventivo', 'configuratore-vernici' ); ?></label>
					<input id="configuratore-vernici-email" type="email" name="email" placeholder="<?php esc_attr_e( 'nome@azienda.it', 'configuratore-vernici' ); ?>" required data-configuratore-email>
				</div>

				<button type="submit" class="button primary"><?php esc_html_e( 'Richiedi preventivo', 'configuratore-vernici' ); ?></button>
			</form>

			<div class="configuratore-vernici__message" aria-live="polite" data-configuratore-messaggio></div>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Process the quote request sent from the frontend.
	 *
	 * @since    1.0.0
	 */
	public function process_quote_request() {
		check_ajax_referer( 'configuratore_vernici_preventivo', 'nonce' );

		$email      = isset( $_POST['email'] ) && is_scalar( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$product    = isset( $_POST['product'] ) && is_scalar( $_POST['product'] ) ? sanitize_text_field( wp_unslash( $_POST['product'] ) ) : '';
		$material   = isset( $_POST['material'] ) && is_scalar( $_POST['material'] ) ? sanitize_text_field( wp_unslash( $_POST['material'] ) ) : '';
		$tool       = isset( $_POST['tool'] ) && is_scalar( $_POST['tool'] ) ? sanitize_text_field( wp_unslash( $_POST['tool'] ) ) : '';
		$mq         = $this->get_posted_float( 'mq' );
		$litri      = $this->get_posted_float( 'litri' );

		if ( ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => __( 'Indirizzo email non valido.', 'configuratore-vernici' ) ), 400 );
		}

		if ( $product_id <= 0 || $mq <= 0 || $litri <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Dati del preventivo non validi.', 'configuratore-vernici' ) ), 400 );
		}

		$post_product = get_post( $product_id );

		if ( ! $post_product || 'product' !== $post_product->post_type || 'publish' !== $post_product->post_status ) {
			wp_send_json_error( array( 'message' => __( 'Prodotto non valido.', 'configuratore-vernici' ) ), 400 );
		}

		if ( ! Configuratore_Vernici_Content_Types::product_is_candidate( $product_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Questo prodotto non è disponibile nel configuratore.', 'configuratore-vernici' ) ), 400 );
		}

		$yield = (float) str_replace( ',', '.', get_post_meta( $product_id, 'resa_litro', true ) );

		if ( $yield <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Resa del prodotto non configurata.', 'configuratore-vernici' ) ), 400 );
		}

		$calculated_liters = round( ( $mq / $yield ) * $this->get_safety_margin_multiplier(), 2 );

		if ( abs( $calculated_liters - $litri ) > 0.05 ) {
			wp_send_json_error( array( 'message' => __( 'Il calcolo inviato non corrisponde ai dati del prodotto.', 'configuratore-vernici' ) ), 400 );
		}

		$product = '' !== $product ? $product : get_the_title( $product_id );

		$request_id = $this->store_quote_request(
			array(
				'email'    => $email,
				'product'  => $product,
				'material' => $material,
				'tool'     => $tool,
				'mq'       => $mq,
				'liters'   => $calculated_liters,
				'yield'    => $yield,
				'page'     => wp_get_referer() ? esc_url_raw( wp_get_referer() ) : home_url(),
			)
		);

		if ( $request_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Non è stato possibile registrare la richiesta. Riprova più tardi.', 'configuratore-vernici' ) ), 500 );
		}

		$recipients = $this->get_notification_recipients();
		$subject   = get_option( 'configuratore_vernici_email_subject', __( 'Nuova richiesta preventivo vernici', 'configuratore-vernici' ) );

		$message = implode(
			"\n",
			array(
				__( 'Nuova richiesta preventivo dal configuratore vernici.', 'configuratore-vernici' ),
				'',
				sprintf( '%s: %s', __( 'Email cliente', 'configuratore-vernici' ), $email ),
				sprintf( '%s: %s', __( 'Prodotto', 'configuratore-vernici' ), $product ),
				sprintf( '%s: %s', __( 'Materiale o supporto', 'configuratore-vernici' ), '' !== $material ? $material : __( 'Non indicato', 'configuratore-vernici' ) ),
				sprintf( '%s: %s', __( 'Strumento di applicazione', 'configuratore-vernici' ), '' !== $tool ? $tool : __( 'Non indicato', 'configuratore-vernici' ) ),
				sprintf( '%s: %.2f', __( 'Metri quadri', 'configuratore-vernici' ), $mq ),
				sprintf( '%s: %.2f L', __( 'Litri calcolati', 'configuratore-vernici' ), $calculated_liters ),
				sprintf( '%s: %.2f m2/L', __( 'Resa prodotto', 'configuratore-vernici' ), $yield ),
				'',
				sprintf( '%s: #%d', __( 'ID richiesta CRM', 'configuratore-vernici' ), $request_id ),
				sprintf( '%s: %s', __( 'Apri richieste', 'configuratore-vernici' ), admin_url( 'admin.php?page=configuratore-vernici-richieste' ) ),
				sprintf( '%s: %s', __( 'Pagina di provenienza', 'configuratore-vernici' ), wp_get_referer() ? esc_url_raw( wp_get_referer() ) : home_url() ),
			)
		);

		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
			'Reply-To: ' . $email,
		);

		$sent = wp_mail( $recipients, sanitize_text_field( $subject ), $message, $headers );

		if ( ! $sent ) {
			wp_send_json_error( array( 'message' => __( 'Non è stato possibile inviare la richiesta. Riprova più tardi.', 'configuratore-vernici' ) ), 500 );
		}

		wp_send_json_success( array( 'message' => __( 'Richiesta inviata correttamente. Ti contatteremo al più presto.', 'configuratore-vernici' ) ) );
	}

	/**
	 * Retrieve published WooCommerce products with a valid yield meta.
	 *
	 * @since    1.0.0
	 * @return   array
	 */
	private function get_products_with_yield() {
		$query = new WP_Query(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'no_found_rows'  => true,
				'meta_query'     => array(
					array(
						'key'     => 'resa_litro',
						'value'   => 0,
						'compare' => '>',
						'type'    => 'NUMERIC',
					),
				),
			)
		);

		$products = array();

		if ( $query->have_posts() ) {
			foreach ( $query->posts as $product ) {
				$yield = (float) str_replace( ',', '.', get_post_meta( $product->ID, 'resa_litro', true ) );

				if ( $yield <= 0 || ! Configuratore_Vernici_Content_Types::product_is_candidate( $product->ID ) ) {
					continue;
				}

				$products[] = array(
					'id'          => $product->ID,
					'title'       => get_the_title( $product ),
					'resa_litro'  => $yield,
				);
			}
		}

		wp_reset_postdata();

		return $products;
	}

	/**
	 * Retrieve published configurator helper posts.
	 *
	 * @since    1.0.0
	 * @param    string $post_type Post type.
	 * @return   array
	 */
	private function get_configurator_posts( $post_type ) {
		$query = new WP_Query(
			array(
				'post_type'      => $post_type,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'no_found_rows'  => true,
			)
		);

		$items = array();

		foreach ( $query->posts as $post ) {
			$items[] = array(
				'id'    => $post->ID,
				'title' => get_the_title( $post ),
			);
		}

		return $items;
	}

	/**
	 * Store a quote request for CRM management.
	 *
	 * @since    1.0.0
	 * @param    array $data Request data.
	 * @return   int
	 */
	private function store_quote_request( $data ) {
		$title = sprintf(
			'%s - %s - %s',
			__( 'Richiesta preventivo', 'configuratore-vernici' ),
			$data['email'],
			current_time( 'd/m/Y H:i' )
		);

		$request_id = wp_insert_post(
			array(
				'post_type'   => 'cv_preventivo',
				'post_status' => 'publish',
				'post_title'  => sanitize_text_field( $title ),
				'meta_input'  => array(
					Configuratore_Vernici_Content_Types::QUOTE_META_STATUS => 'new',
					'_cv_customer_email' => sanitize_email( $data['email'] ),
					'_cv_product'        => sanitize_text_field( $data['product'] ),
					'_cv_material'       => sanitize_text_field( $data['material'] ),
					'_cv_tool'           => sanitize_text_field( $data['tool'] ),
					'_cv_mq'             => (float) $data['mq'],
					'_cv_liters'         => (float) $data['liters'],
					'_cv_yield'          => (float) $data['yield'],
					'_cv_page'           => esc_url_raw( $data['page'] ),
				),
			),
			true
		);

		if ( is_wp_error( $request_id ) ) {
			return 0;
		}

		return (int) $request_id;
	}

	/**
	 * Get notification recipients.
	 *
	 * @since    1.0.0
	 * @return   array
	 */
	private function get_notification_recipients() {
		$raw_recipients = get_option( 'configuratore_vernici_recipient_emails', '' );

		if ( '' === $raw_recipients ) {
			$raw_recipients = get_option( 'configuratore_vernici_recipient_email', get_option( 'admin_email' ) );
		}

		$emails = preg_split( '/[\s,;]+/', (string) $raw_recipients );
		$recipients = array();

		foreach ( $emails as $email ) {
			$email = sanitize_email( $email );

			if ( is_email( $email ) ) {
				$recipients[] = $email;
			}
		}

		if ( empty( $recipients ) ) {
			$recipients[] = get_option( 'admin_email' );
		}

		return array_values( array_unique( $recipients ) );
	}

	/**
	 * Retrieve the configured safety margin as a multiplier.
	 *
	 * @since    1.0.0
	 * @return   float
	 */
	private function get_safety_margin_multiplier() {
		$margin = (float) get_option( 'configuratore_vernici_safety_margin', 10 );

		if ( $margin < 0 ) {
			$margin = 0;
		}

		return 1 + ( $margin / 100 );
	}

	/**
	 * Retrieve the free delivery threshold.
	 *
	 * @since    1.0.0
	 * @return   float
	 */
	private function get_free_delivery_threshold() {
		$threshold = (float) get_option( 'configuratore_vernici_free_delivery_threshold', 30 );

		return $threshold > 0 ? $threshold : 30;
	}

	/**
	 * Build a tel: URL from a configured phone number.
	 *
	 * @since    1.0.0
	 * @param    string $phone Phone number.
	 * @return   string
	 */
	private function get_phone_href( $phone ) {
		$phone = preg_replace( '/[^0-9+]/', '', (string) $phone );

		if ( '' === $phone ) {
			return '';
		}

		return 'tel:' . $phone;
	}

	/**
	 * Retrieve a float value from POST data.
	 *
	 * @since    1.0.0
	 * @param    string $key POST key.
	 * @return   float
	 */
	private function get_posted_float( $key ) {
		if ( ! isset( $_POST[ $key ] ) || ! is_scalar( $_POST[ $key ] ) ) {
			return 0;
		}

		return (float) str_replace( ',', '.', wp_unslash( $_POST[ $key ] ) );
	}

}
